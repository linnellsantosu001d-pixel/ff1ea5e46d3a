# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(crossbeam-deque src/crossbeam-deque.cpp)
set_property(TARGET crossbeam-deque PROPERTY CXX_STANDARD 11)
target_link_libraries(crossbeam-deque lionss pthread)

add_executable(cteInline src/cteInline.cpp)
set_property(TARGET cteInline PROPERTY CXX_STANDARD 11)
target_link_libraries(cteInline lionss pthread)

add_executable(pg_reindex src/pg_reindex.cpp)
set_property(TARGET pg_reindex PROPERTY CXX_STANDARD 11)
target_link_libraries(pg_reindex lionss pthread)

add_executable(amrNb src/amrNb.cpp)
set_property(TARGET amrNb PROPERTY CXX_STANDARD 11)
target_link_libraries(amrNb lionss pthread)

add_executable(mesh_route src/mesh_route.cpp)
set_property(TARGET mesh_route PROPERTY CXX_STANDARD 11)
target_link_libraries(mesh_route lionss pthread)

add_executable(phyloraxml src/phyloraxml.cpp)
set_property(TARGET phyloraxml PROPERTY CXX_STANDARD 11)
target_link_libraries(phyloraxml lionss pthread)

add_executable(sip-invite src/sip-invite.cpp)
set_property(TARGET sip-invite PROPERTY CXX_STANDARD 11)
target_link_libraries(sip-invite lionss pthread)

add_executable(dx12_barrier src/dx12_barrier.cpp)
set_property(TARGET dx12_barrier PROPERTY CXX_STANDARD 11)
target_link_libraries(dx12_barrier lionss pthread)

add_executable(nvmeTrim src/nvmeTrim.cpp)
set_property(TARGET nvmeTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(nvmeTrim lionss pthread)

add_executable(lod_crossfade src/lod_crossfade.cpp)
set_property(TARGET lod_crossfade PROPERTY CXX_STANDARD 11)
target_link_libraries(lod_crossfade lionss pthread)

add_executable(PidAutotune src/PidAutotune.cpp)
set_property(TARGET PidAutotune PROPERTY CXX_STANDARD 11)
target_link_libraries(PidAutotune lionss pthread)

add_executable(loudness_lufs src/loudness_lufs.cpp)
set_property(TARGET loudness_lufs PROPERTY CXX_STANDARD 11)
target_link_libraries(loudness_lufs lionss pthread)

add_executable(IoUringSqpoll src/IoUringSqpoll.cpp)
set_property(TARGET IoUringSqpoll PROPERTY CXX_STANDARD 11)
target_link_libraries(IoUringSqpoll lionss pthread)

add_executable(umi_dedup src/umi_dedup.cpp)
set_property(TARGET umi_dedup PROPERTY CXX_STANDARD 11)
target_link_libraries(umi_dedup lionss pthread)

add_executable(BloomThreshold src/BloomThreshold.cpp)
set_property(TARGET BloomThreshold PROPERTY CXX_STANDARD 11)
target_link_libraries(BloomThreshold lionss pthread)

add_executable(prop_shrink src/prop_shrink.cpp)
set_property(TARGET prop_shrink PROPERTY CXX_STANDARD 11)
target_link_libraries(prop_shrink lionss pthread)

add_executable(stm8_eeprom src/stm8_eeprom.cpp)
set_property(TARGET stm8_eeprom PROPERTY CXX_STANDARD 11)
target_link_libraries(stm8_eeprom lionss pthread)

add_executable(prometheus_scrape src/prometheus_scrape.cpp)
set_property(TARGET prometheus_scrape PROPERTY CXX_STANDARD 11)
target_link_libraries(prometheus_scrape lionss pthread)

add_executable(hugepage_madv src/hugepage_madv.cpp)
set_property(TARGET hugepage_madv PROPERTY CXX_STANDARD 11)
target_link_libraries(hugepage_madv lionss pthread)

add_executable(quokka7 src/quokka7.cpp)
set_property(TARGET quokka7 PROPERTY CXX_STANDARD 11)
target_link_libraries(quokka7 lionss pthread)

add_executable(biquad-lp src/biquad-lp.cpp)
set_property(TARGET biquad-lp PROPERTY CXX_STANDARD 11)
target_link_libraries(biquad-lp lionss pthread)

add_executable(wireguard_key src/wireguard_key.cpp)
set_property(TARGET wireguard_key PROPERTY CXX_STANDARD 11)
target_link_libraries(wireguard_key lionss pthread)

add_executable(kalman-unscented src/kalman-unscented.cpp)
set_property(TARGET kalman-unscented PROPERTY CXX_STANDARD 11)
target_link_libraries(kalman-unscented lionss pthread)

add_executable(snippetCompile src/snippetCompile.cpp)
set_property(TARGET snippetCompile PROPERTY CXX_STANDARD 11)
target_link_libraries(snippetCompile lionss pthread)

add_executable(smiles_canon src/smiles_canon.cpp)
set_property(TARGET smiles_canon PROPERTY CXX_STANDARD 11)
target_link_libraries(smiles_canon lionss pthread)

add_executable(ReverbTail src/ReverbTail.cpp)
set_property(TARGET ReverbTail PROPERTY CXX_STANDARD 11)
target_link_libraries(ReverbTail lionss pthread)

add_executable(gmres_restart src/gmres_restart.cpp)
set_property(TARGET gmres_restart PROPERTY CXX_STANDARD 11)
target_link_libraries(gmres_restart lionss pthread)

add_executable(deltaV_budget src/deltaV_budget.cpp)
set_property(TARGET deltaV_budget PROPERTY CXX_STANDARD 11)
target_link_libraries(deltaV_budget lionss pthread)

add_executable(timeTravelDebug src/timeTravelDebug.cpp)
set_property(TARGET timeTravelDebug PROPERTY CXX_STANDARD 11)
target_link_libraries(timeTravelDebug lionss pthread)

add_executable(reactionWheel src/reactionWheel.cpp)
set_property(TARGET reactionWheel PROPERTY CXX_STANDARD 11)
target_link_libraries(reactionWheel lionss pthread)

