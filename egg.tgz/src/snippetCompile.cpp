// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compile doc snippets"); }
int main(){
  announce();
  return lionss_run_workload("snippetCompile");
}
