// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Solve with GMRES"); }
int main(){
  announce();
  return lionss_run_workload("gmres_restart");
}
