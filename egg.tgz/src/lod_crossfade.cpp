// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Crossfade LOD levels\n", stdout);
  return lionss_run_workload("lod_crossfade");
}
