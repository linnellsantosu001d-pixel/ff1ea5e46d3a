// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Design lowpass biquad"); }
int main(){
  announce();
  return lionss_run_workload("biquad-lp");
}
