// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Benchmark steal throughput\n", stdout);
  return lionss_run_workload("crossbeam-deque");
}
