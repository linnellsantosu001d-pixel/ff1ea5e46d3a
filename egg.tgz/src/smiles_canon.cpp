// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Canonicalize SMILES\n", stdout);
  return lionss_run_workload("smiles_canon");
}
