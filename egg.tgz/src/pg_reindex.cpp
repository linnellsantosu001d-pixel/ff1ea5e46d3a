// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Reindex concurrently"); }
int main(){
  announce();
  return lionss_run_workload("pg_reindex");
}
